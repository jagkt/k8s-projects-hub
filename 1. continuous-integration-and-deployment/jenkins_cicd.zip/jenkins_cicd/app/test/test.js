const assert = require("assert");

describe("Sample Test", () => {
  it("should return true", () => {
    assert.equal(1, 1);
  });
});
